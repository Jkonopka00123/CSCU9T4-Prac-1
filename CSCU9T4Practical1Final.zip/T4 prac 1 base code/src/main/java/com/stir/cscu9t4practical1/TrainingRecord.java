// An implementation of a Training Record as an ArrayList
package com.stir.cscu9t4practical1;


import java.util.*;


public class TrainingRecord
{
    private List<Entry> tr;
    
    public TrainingRecord()
    {
        tr = new ArrayList<Entry>();
    } //constructor

    // add a record to the list
   public void addEntry(Entry e)
   {
       tr.add(e);
   } // addClass


    /**
     * Finds all runs by all runners done on specified date
     * @param d day
     * @param m month
     * @param y year
     * @return returns a string containing all performed runs or if none found an error message
     */
   public String findAll (int d, int m, int y)
   {
       ListIterator<Entry> iter = tr.listIterator();
       String result = "";
       while (iter.hasNext())
       {
          Entry current = iter.next();
          if (current.getDay()==d && current.getMonth()==m && current.getYear()==y)
             result = result + current.getEntry(); //adds each record found onto the string
       }
       if (result.equals(""))
       {
           //message for no results is set at the end
           result = "No entries found";
       }
       return result;
   } // findAll



    public String lookupEntry (int d, int m, int y)
    {
        ListIterator<Entry> iter = tr.listIterator();
        String result = "No entries found";
        while (iter.hasNext())
        {
            Entry current = iter.next();
            if (current.getDay()==d && current.getMonth()==m && current.getYear()==y)
                result = current.getEntry();
        }
        return result;
    } // lookupEntry



    /**
     * Finds if a given runner has completed a run on a given date
     * @param n name of runner
     * @param d day
     * @param m month
     * @param y year
     * @return true if runner found
     * This is just lookupEntry changed a bit and used for validation
     */
    public boolean findRunnerDate (String n, int d, int m, int y)
    {
        ListIterator<Entry> iter = tr.listIterator();
        while (iter.hasNext())
        {
            Entry current = iter.next();
            if (current.getName().equals(n) && current.getDay()==d && current.getMonth()==m && current.getYear()==y)
                return true;
        }
            return false;
    } //findRunnerDate


    /**
     * Finds all runs performed by a runner
     * Name has to be a full match
     * @param n name
     * @return string containing all runs performed by runner or error message
     */
    public String findRunnerAll (String n)
    {
        String message = "";
        ListIterator<Entry> iter = tr.listIterator();
        while (iter.hasNext())
        {
            Entry current = iter.next();
            if (current.getName().equals(n))
                message = message + current.getEntry();
        }
        if (message.equals(""))
            message = "Could not find any runs, please ensure the name is spelled correctly";
        return message;
    } //findRunnerAll


    /**
     * Removes a specified run, name and date have to fully match for a run to be removed
     * @param n name
     * @param d day
     * @param m month
     * @param y year
     * @return string with either error or success message
     */
    public String removeRun(String n, int d, int m, int y)
    {
        String message = "Entry not found";
        ListIterator<Entry> iter = tr.listIterator();
        while (iter.hasNext())
        {
            Entry current = iter.next();
            if (current.getName().equals(n) && current.getDay()==d && current.getMonth()==m && current.getYear()==y)
            {
                tr.remove(current);
                return "Entry removed";
            }
        }
        return message;
    }//removeRun



   // Count the number of entries
   public int getNumberOfEntries()
   {
       return tr.size();
   }
   // Clear all entries
   public void clearAllEntries(){
       tr.clear();
   }
   
} // TrainingRecord