// GUI and main program for the Training Record
package com.stir.cscu9t4practical1;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.lang.Number;


//                   Beware the dragon
//                Guardian of terrible code
//
//
//
//                 ___====-_  _-====___
//           _--^^^#####//      \\#####^^^--_
//        _-^##########// (    ) \\##########^-_
//       -############//  |\^^/|  \\############-
//     _/############//   (@::@)   \\############\_
//    /#############((     \\//     ))#############\
//   -###############\\    (oo)    //###############-
//  -#################\\  / VV \  //#################-
// -###################\\/      \//###################-
//_#/|##########/\######(   /\   )######/\##########|\#_
//|/ |#/\#/\#/\/  \#/\##\  |  |  /##/\#/  \/\#/\#/\#| \|
//`  |/  V  V  `   V  \#\| |  | |/#/  V   '  V  V  \|  '
//   `   `  `      `   / | |  | | \   '      '  '   '
//                    (  | |  | |  )
//                   __\ | |  | | /__
//                  (vvv(VVV)(VVV)vvv)



public class TrainingRecordGUI extends JFrame implements ActionListener {

    private JTextField name = new JTextField(30);
    private JTextField day = new JTextField(2);
    private JTextField month = new JTextField(2);
    private JTextField year = new JTextField(4);
    private JTextField hours = new JTextField(2);
    private JTextField mins = new JTextField(2);
    private JTextField secs = new JTextField(2);
    private JTextField dist = new JTextField(4);
    //imagine having to evaluate my code, i pitty you
    private JLabel labn = new JLabel(" Name:");
    private JLabel labd = new JLabel(" Day:");
    private JLabel labm = new JLabel(" Month:");
    private JLabel laby = new JLabel(" Year:");
    private JLabel labh = new JLabel(" Hours:");
    private JLabel labmm = new JLabel(" Mins:");
    private JLabel labs = new JLabel(" Secs:");
    private JLabel labdist = new JLabel(" Distance (km):");
    private JButton addR = new JButton("Add");
    private JButton lookUpByDate = new JButton("Look Up"); //why do we need this, this button has leprosy

    private JButton findAllByDate = new JButton("Find All"); //Button for part 1
    private JButton findRunnerAll = new JButton("Find Runner"); //Button for part 9
    private JButton removeRun = new JButton("Remove Run");  //Button for part 11

    private JTextField runType = new JTextField(10);
    private JTextField additional1 = new JTextField(10);
    private JTextField additional2 = new JTextField(10);
    private JLabel labadd1 = new JLabel(" Repetitions/Terrain/Where:");
    private JLabel labadd2 = new JLabel(" Recovery/Tempo:");
    private JLabel runLbl = new JLabel("Type of run");


    private TrainingRecord myAthletes = new TrainingRecord();

    private JTextArea outputArea = new JTextArea(5, 50);

    public static void main(String[] args)
    {
        TrainingRecordGUI applic = new TrainingRecordGUI();
    } // main

    // set up the GUI 
    public TrainingRecordGUI() {
        super("Training Record");
        setLayout(new FlowLayout());
        add(labn);
        add(name);
        name.setEditable(true);
        add(labd);
        add(day);
        day.setEditable(true);
        add(labm);
        add(month);
        month.setEditable(true);
        add(laby);
        add(year);
        year.setEditable(true);
        add(labh);
        add(hours);
        hours.setEditable(true);
        add(labmm);
        add(mins);
        mins.setEditable(true);
        add(labs);
        add(secs);
        secs.setEditable(true);
        add(labdist);
        add(dist);

        add(runLbl);
        add(runType);
        add(labadd1);
        add(additional1);
        add(labadd2);
        add(additional2);

        dist.setEditable(true);
        add(addR);
        addR.addActionListener(this);

        add(lookUpByDate);
        lookUpByDate.setEnabled(false);
        lookUpByDate.addActionListener(this);

        add(findAllByDate);
        findAllByDate.setEnabled(false);
        findAllByDate.addActionListener(this);

        add(findRunnerAll);
        findRunnerAll.setEnabled(false);
        findRunnerAll.addActionListener(this);

        add(removeRun);
        removeRun.setEnabled(false);
        removeRun.addActionListener(this);



        add(outputArea);
        outputArea.setEditable(false);
        setSize(850, 250);
        setVisible(true);
        blankDisplay();


        
    } // constructor

    // listen for and respond to GUI events 
    public void actionPerformed(ActionEvent event)
    {
        String message = "";
        if (event.getSource() == addR) {
            message = addEntry("generic");
        }
        if (event.getSource() == lookUpByDate) {
            message = lookupEntry();
        }
        if (event.getSource() == findAllByDate)
        {
            message = findAll();
        }
        if (event.getSource() == findRunnerAll)
        {
            message = findRunnerAll();
        }
        if (event.getSource() == removeRun)
        {
            message = removeRun();
        }
        outputArea.setText(message);
        blankDisplay();
    } // actionPerformed

    public String addEntry(String what) {

        String message = "Record added\n"; //sets default return message
        boolean isInt = true; //determines if date and time are are ints if not entry not added

        if (name.getText().equals("")) // i hate java strings and the fact that you need to use .equals() instead of ==
                                       // no joke i spent 20 mins trying to get this to work because of that, i want to cry
        {
            message = "The name field cannot be left blank\n";
        }

        else
        {
            String n = name.getText();
            /*
            Checks if date or time is not an integer
            if not, sets variable isInt to false and
            sets variable message to output an appropriate error message
             */
            try
            {
                Integer.parseInt(month.getText());
                Integer.parseInt(day.getText());
                Integer.parseInt(year.getText());
                Integer.parseInt(hours.getText());
                Integer.parseInt(mins.getText());
                Integer.parseInt(secs.getText());
                java.lang.Float.parseFloat(dist.getText());
            }
            catch (NumberFormatException e)
            {
                message = "The date (day, month, year), distance and time (hours, mins, secs) have to be a number";
                isInt = false;
            }
            if (isInt)
            {

                int m = Integer.parseInt(month.getText());
                int d = Integer.parseInt(day.getText());
                int y = Integer.parseInt(year.getText());
                float km = java.lang.Float.parseFloat(dist.getText());
                int h = Integer.parseInt(hours.getText());
                int mm = Integer.parseInt(mins.getText());
                int s = Integer.parseInt(secs.getText());

                /*
                ensure that the time or date added exists
                eg disallowing a time of 1:112:70 or a date of 50/13/2021
                also prevents a negative time, date or distance from being added
                 */
                if (mm > 59 || s > 59 || d > 31 || m > 12 || m < 0 || mm < 0 || d < 0 || y < 0 || s < 0 || km < 0 || h < 0)
                {
                    return "There was an error with either the time date or distance please ensure that the entered values\nare possible and that no negative numbers were entered";
                }


                //ensures that only 1 entry a day can be added per day
                if(myAthletes.findRunnerDate(n, d, m, y))
                {
                    return n + " has already completed a run today";
                }

                else
                    if(runType.getText().toLowerCase(Locale.ROOT).equals(""))
                    {
                        System.out.println("Adding " + what + " entry to the records");
                        Entry a = new Entry(n, d, m, y, h, mm, s, km);
                        myAthletes.addEntry(a);

                        //sets buttons to be usable
                        findAllByDate.setEnabled(true);
                        lookUpByDate.setEnabled(true);
                        findRunnerAll.setEnabled(true);
                        removeRun.setEnabled(true);
                    }
                    if(runType.getText().toLowerCase(Locale.ROOT).equals("sprint"))
                    {
                        /*
                        Checks if the 2 additional inputs for sprint are ints
                        if not, sets variable isInt to false and
                        sets variable message to output an appropriate error message
                         */
                        try
                        {
                            Integer.parseInt(additional1.getText());
                            Integer.parseInt(additional2.getText());
                        }
                        catch (NumberFormatException e)
                        {
                            message = "The repetitions and recovery have to be a number";
                            isInt = false;
                        }
                        if (isInt)
                        {
                            int rep = Integer.parseInt(additional1.getText());
                            int rec = Integer.parseInt((additional2.getText()));
                            System.out.println("Adding " + what + " entry to the records");
                            SprintEntry a = new SprintEntry(n, d, m, y, h, mm, s, km, rep, rec);
                            myAthletes.addEntry(a);

                            //sets buttons to be usable
                            findAllByDate.setEnabled(true);
                            lookUpByDate.setEnabled(true);
                            findRunnerAll.setEnabled(true);
                            removeRun.setEnabled(true);

                        }
                    }
                    if (runType.getText().toLowerCase(Locale.ROOT).equals("swim"))
                    {
                        /*
                        Ensure that additional1 is not empty
                        dont need to check if anything written in additional2
                        as that field is not used in swimEntry
                         */
                        if(additional1.getText().equals(""))
                        {
                            message = "Please specify where the swim took place";
                            return message;
                        }
                        String whr = additional1.getText(); //where
                        System.out.println("Adding " + what + " entry to the records");
                        SwimEntry a = new SwimEntry(n, d, m, y, h, mm, s, km, whr);
                        myAthletes.addEntry(a);


                        //sets buttons to be usable
                        findAllByDate.setEnabled(true);
                        lookUpByDate.setEnabled(true);
                        findRunnerAll.setEnabled(true);
                        removeRun.setEnabled(true);
                    }

                if (runType.getText().toLowerCase(Locale.ROOT).equals("cycle"))
                {
                    /*
                    Ensures that the 2 additional fields in entry form aren't empty for cycle run
                    If 1 or both are empty prints out error message
                     */
                    if(additional1.getText().equals("") || additional2.getText().equals(""))
                    {
                        message = "Please specify terrain and speed";
                        return message;
                    }
                    //speed for cycleRun can only be the specified entries below
                    if (additional2.getText().equals("slow") || additional2.getText().equals("moderate") || additional2.getText().equals("fast"))
                    {
                        String trr = additional1.getText(); //terrain
                        String spd = additional2.getText(); //speed
                        System.out.println("Adding " + what + " entry to the records");
                        CycleEntry a = new CycleEntry(n, d, m, y, h, mm, s, km, trr, spd);
                        myAthletes.addEntry(a);


                        //sets buttons to be usable
                        findAllByDate.setEnabled(true);
                        lookUpByDate.setEnabled(true);
                        findRunnerAll.setEnabled(true);
                        removeRun.setEnabled(true);

                    }
                    else
                    {
                        message = "The speed can only be fast, moderate or slow";
                    }

                }
            }
        }

        return message;
    }

    public String lookupEntry()
    {
        int m = Integer.parseInt(month.getText());
        int d = Integer.parseInt(day.getText());
        int y = Integer.parseInt(year.getText());
        outputArea.setText("looking up record ...");
        String message = myAthletes.lookupEntry(d, m, y);
        return message;
    }

    public String findAll()
    {
        int m = Integer.parseInt(month.getText());
        int d = Integer.parseInt(day.getText());
        int y = Integer.parseInt(year.getText());
        outputArea.setText("looking up record ...");
        String message = myAthletes.findAll(d, m, y);
        return message;
    }

    public String findRunnerAll()
    {
        String n = name.getText();
        outputArea.setText("looking up record ...");
        String message = myAthletes.findRunnerAll(n);
        return message;
    }

    public String removeRun()
    {
        String n = name.getText();
        int m = Integer.parseInt(month.getText());
        int d = Integer.parseInt(day.getText());
        int y = Integer.parseInt(year.getText());
        outputArea.setText("removing entry ...");
        String message = myAthletes.removeRun(n, d, m, y);

        //if the run removed is the only run in the list
        //disables all buttons apart from addR button
        if (myAthletes.getNumberOfEntries() < 1)
        {
            findAllByDate.setEnabled(false);
            lookUpByDate.setEnabled(false);
            findRunnerAll.setEnabled(false);
            removeRun.setEnabled(false);
        }
        return message;
    }


    public void blankDisplay() {
        name.setText("");
        day.setText("");
        month.setText("");
        year.setText("");
        hours.setText("");
        mins.setText("");
        secs.setText("");
        dist.setText("");
        additional1.setText("");
        additional2.setText("");
        runType.setText("");

    }// blankDisplay
    // Fills the input fields on the display for testing purposes only
    public void fillDisplay(Entry ent) {
        name.setText(ent.getName());
        day.setText(String.valueOf(ent.getDay()));
        month.setText(String.valueOf(ent.getMonth()));
        year.setText(String.valueOf(ent.getYear()));
        hours.setText(String.valueOf(ent.getHour()));
        mins.setText(String.valueOf(ent.getMin()));
        secs.setText(String.valueOf(ent.getSec()));
        dist.setText(String.valueOf(ent.getDistance()));
    }

} // TrainingRecordGUI

